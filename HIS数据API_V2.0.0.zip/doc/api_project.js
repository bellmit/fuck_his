define({
  "name": "Our HIS data API",
  "version": "0.1.0",
  "description": "The data API of our team in the Course named fucking MI.",
  "title": "HIS Data API",
  "url": "http://118.24.117.188/his",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-10-23T14:04:42.434Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
